from sqlalchemy.orm import selectinload

from addons.Automobiles.models.contact_models import Contact, ContactAuditLog
from addons.Automobiles.models import Fleet
from core import logger
import socket
from sqlalchemy import func, or_  # <--- C'est cette ligne qui manque
from datetime import datetime
import os

from core.workers.query_cache import query_cache

class ContactController:
    def __init__(self, db_session, current_user_id):
        self.db = db_session
        # Accepte soit l'ID utilisateur, soit l'objet User.
        # Dans le second cas, on prend simplement l'attribut .id pour éviter
        # d'essayer d'insérer tout l'objet dans la colonne created_by.
        self.current_user_id = getattr(current_user_id, 'id', current_user_id)

    # --- LECTURE ---
    # def get_all_contacts(self):
    #     """Récupère tous les contacts (Assurés, Prospects, etc.)"""
    #     try:
    #         return self.db.query(Contact).all()
    #     except Exception as e:
    #         print(f"ERREUR get_all: {e}")
    #         return []

    def get_all_contacts(self, force_refresh: bool = False):
        """Récupère tous les contacts avec cache simple"""
        
        cache_key = "contacts_all"
        
        if not force_refresh:
            cached = query_cache.get(cache_key)
            if cached is not None:
                logger.info(f"📦 Cache hit: {len(cached)} contacts")
                return cached
        
        # Charger depuis la base
        try:
            contacts = self.db.query(Contact).all()
            query_cache.set(cache_key, contacts, ttl=300)
            logger.info(f"💾 Cache miss: {len(contacts)} contacts chargés")
            return contacts
        except Exception as e:
            logger.error(f"Erreur chargement contacts: {e}")
            return []

    def get_contact_by_id(self, contact_id):
        """Récupère un contact précis par son ID unique"""
        try:
            return self.db.query(Contact).filter(Contact.id == contact_id).first()
        except Exception as e:
            print(f"ERREUR get_by_id: {e}")
            return None

    # --- CRÉATION ---
    def get_client_ip(self):
        try:
            return socket.gethostbyname(socket.gethostname())
        except:
            return "127.0.0.1"
    
    def create_contact(self, data):
        try:
            # 1. Extraire l'image brute (elle ne doit pas aller dans l'objet Contact)
            image_brute = data.pop("image_brute", None)
            
            # 2. Filtrer les données pour ne garder que ce qui existe en BD
            # Cela évite l'erreur "AttributeError" ou "Invalid Column"
            allowed_keys = [c.key for c in Contact.__table__.columns]
            # On force la correspondance pour charge_clientele si nécessaire
            filtered_data = {k: v for k, v in data.items() if k in allowed_keys or k == 'charge_clientele'}

            # 3. Créer l'objet
            new_contact = Contact(**filtered_data)

            # 4. Gérer la photo si elle existe
            if image_brute is not None:
                # Sauvegarde physique (assurez-vous que le dossier existe)
                if not os.path.exists("uploads/photos"):
                    os.makedirs("uploads/photos")
                
                photo_name = f"IMG_{new_contact.nom}_{datetime.now().strftime('%H%M%S')}.jpg"
                photo_path = os.path.join("uploads/photos", photo_name)
                
                # Conversion QImage vers OpenCV ou sauvegarde directe
                # Si image_brute est une QImage (venant de la vue) :
                image_brute.save(photo_path, "JPG")
                new_contact.photo_path = photo_path

            # 5. Traçabilité
            new_contact.created_by = self.current_user_id
            new_contact.created_ip = self.get_client_ip()

            self.db.add(new_contact)
            self.db.commit()
            self.db.refresh(new_contact)
            return new_contact, True, "Contact créé avec succès"

        except Exception as e:
            self.db.rollback()
            # AFFICHE L'ERREUR RÉELLE DANS LA CONSOLE POUR LE DEBUG
            print(f"--- ERREUR CRÉATION CONTACT ---")
            print(f"Détails : {str(e)}")
            return None, False, f"Erreur technique : {str(e)}"
        
    # --- MISE À JOUR ---
    def update_contact(self, contact_id, data):
        try:
            # ... logique de mise à jour ...
            self.db.commit()  # <--- INDISPENSABLE
            return True
        except:
            self.db.rollback()
        return False

    # --- SUPPRESSION ---
    def delete_contact(self, contact_id):
        try:
            contact = self.db.query(Contact).filter(Contact.id == contact_id).first()
            if contact:
                self.db.delete(contact)
                self.db.commit()  # <--- INDISPENSABLE
                return True
            return False
        except Exception as e:
            print(f"Erreur : {e}")
            self.db.rollback() # Annule en cas d'erreur pour ne pas bloquer la session
            return False
        
    def log_contact_action(self, action, contact_id, details=""):
        try:
            # Récupération de l'adresse IP locale
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
            
            new_log = ContactAuditLog(
                user_id=self.current_user_id,
                contact_id=contact_id,
                action=action,
                details=details,
                ip_address=ip_address # On enregistre l'IP ici
            )
            self.db.add(new_log)
            self.db.commit()
        except Exception as e:
            print(f"Erreur d'audit (IP) : {e}")

    def get_audit_logs(self):
        """Récupère tous les logs pour l'affichage (Aucun argument requis)"""
        try:
            return self.db.query(ContactAuditLog).order_by(ContactAuditLog.created_at.desc()).all()
        except Exception as e:
            print(f"Erreur de lecture audit : {e}")
            return []
        
    def get_contact_stats(self):
        try:
            # Correction : utiliser type_client au lieu de type_contact
            results = self.db.query(
                Contact.type_client, 
                func.count(Contact.id)
            ).group_by(Contact.type_client).all()
            return {row[0] if row[0] else "Inconnu": row[1] for row in results}
        except Exception as e:
            self.db.rollback() # Libère la transaction
            print(f"Erreur stats : {e}")
            return {}      
        
    def on_search_changed(self, text):
        """Filtre les contacts affichés en fonction de la saisie."""
        search_text = text.lower()
        
        # 1. Récupérer tous les contacts depuis le contrôleur (ou un cache local)
        all_contacts = self.controller.get_all_contacts()
        
        # 2. Filtrer la liste
        filtered_contacts = []
        for c in all_contacts:
            # On cherche dans le nom, le prénom, le téléphone ou le type
            match_found = (
                search_text in (c.nom or "").lower() or 
                search_text in (c.prenom or "").lower() or
                search_text in (c.telephone or "").lower() or
                search_text in (c.type_contact or "").lower()
            )
            if match_found:
                filtered_contacts.append(c)
        
        # 3. Rafraîchir l'affichage des cartes et des stats
        self.display_contacts(filtered_contacts)

    def get_contacts_for_combo(self, text=""):
        """Récupère les compagnies pour le combo de filtrage."""
        query = self.db.query(Contact)
        if text:
            query = query.filter(Contact.nom.ilike(f"%{text}%"))
        return query.all()

    def search_contacts(self, search_text):
        if not self.db:
            print("Erreur : Aucune session DB dans ContactController")
            return []
            
        # On sécurise le pattern de recherche
        pattern = f"%{search_text}%"
        
        return self.db.query(Contact).filter(
            Contact.nom.ilike(pattern) | 
            Contact.prenom.ilike(pattern) | 
            Contact.telephone.ilike(pattern) | 
            Contact.email.ilike(pattern) | 
            Contact.nature.ilike(pattern)
        ).limit(10).all()
    
    def get_report_data(self):
        """Prépare les données groupées pour le PDF."""
        contacts = self.get_all_contacts()
        stats = self.get_contact_stats()
        return contacts, stats
    
    # Dans le contrôleur des contacts
    def get_all(self):
        return self.db.query(Contact).all()

    def count_by_type(self, client_type):
        return self.db.query(Contact).filter(Contact.nature == client_type).count()