-- add_exonere_dta_postgres.sql
-- Version PostgreSQL

-- Ajouter la colonne avec valeur par défaut
ALTER TABLE vehicles ADD COLUMN exonere_dta BOOLEAN DEFAULT FALSE NOT NULL;

-- Si vous voulez la colonne nullable
-- ALTER TABLE vehicles ADD COLUMN exonere_dta BOOLEAN DEFAULT FALSE;

-- Mettre à jour les enregistrements existants
UPDATE vehicles SET exonere_dta = FALSE WHERE exonere_dta IS NULL;

-- Vérifier
SELECT id, immatriculation, exonere_dta FROM vehicles LIMIT 10;

-- addons/Automobiles/migrations/add_driver_fields_to_contacts.sql (PostgreSQL)

-- 1. Ajouter les champs manquants (sans AFTER)
ALTER TABLE contacts 
ADD COLUMN statut VARCHAR(20) DEFAULT 'Actif';

ALTER TABLE contacts 
ADD COLUMN profession VARCHAR(100) NULL;

ALTER TABLE contacts 
ADD COLUMN code_chauffeur VARCHAR(50) UNIQUE NULL;

ALTER TABLE contacts 
ADD COLUMN specialite VARCHAR(100) NULL;

ALTER TABLE contacts 
ADD COLUMN annees_experience INTEGER DEFAULT 0;

ALTER TABLE contacts 
ADD COLUMN subscriber_id INTEGER NULL;

-- 2. Ajouter la clé étrangère (auto-référence)
ALTER TABLE contacts 
ADD CONSTRAINT fk_contacts_subscriber 
FOREIGN KEY (subscriber_id) REFERENCES contacts(id) 
ON DELETE SET NULL;

-- 3. Ajouter les index
CREATE INDEX idx_contacts_subscriber_id ON contacts(subscriber_id);
CREATE INDEX idx_contacts_type_client ON contacts(type_client);
CREATE INDEX idx_contacts_code_chauffeur ON contacts(code_chauffeur);
CREATE INDEX idx_contacts_statut ON contacts(statut);

-- 4. Supprimer la colonne photo_path (si elle existe)
-- ALTER TABLE contacts DROP COLUMN photo_path CASCADE;


-- Ajouter les colonnes manquantes dans drivers
ALTER TABLE drivers ADD COLUMN code_chauffeur VARCHAR(50) UNIQUE;
ALTER TABLE drivers ADD COLUMN specialite VARCHAR(100);
ALTER TABLE drivers ADD COLUMN annees_experience INTEGER DEFAULT 0;
ALTER TABLE drivers ADD COLUMN notes TEXT;
ALTER TABLE drivers ADD COLUMN created_by INTEGER REFERENCES utilisateurs(id);
ALTER TABLE drivers ADD COLUMN updated_by INTEGER REFERENCES utilisateurs(id);
ALTER TABLE drivers ADD COLUMN created_at TIMESTAMP DEFAULT NOW();
ALTER TABLE drivers ADD COLUMN updated_at TIMESTAMP DEFAULT NOW();

-- Supprimer les colonnes chauffeur de contacts (si elles existent)
ALTER TABLE contacts DROP COLUMN IF EXISTS code_chauffeur;
ALTER TABLE contacts DROP COLUMN IF EXISTS specialite;
ALTER TABLE contacts DROP COLUMN IF EXISTS annees_experience;
ALTER TABLE contacts DROP COLUMN IF EXISTS subscriber_id;