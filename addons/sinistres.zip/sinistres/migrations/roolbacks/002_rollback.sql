BEGIN;

-- Supprimer la contrainte de cohérence
ALTER TABLE lometa_sinistres
DROP CONSTRAINT IF EXISTS ck_lometa_sinistres_flotte_vehicule;

-- Supprimer flotte_id
DROP INDEX IF EXISTS ix_lometa_sinistres_flotte_id;
ALTER TABLE lometa_sinistres
DROP CONSTRAINT IF EXISTS fk_lometa_sinistres_flotte;
ALTER TABLE lometa_sinistres
DROP COLUMN IF EXISTS flotte_id;

-- Supprimer vehicule_sinistre_id
DROP INDEX IF EXISTS ix_lometa_sinistres_vehicule_sinistre_id;
ALTER TABLE lometa_sinistres
DROP CONSTRAINT IF EXISTS fk_lometa_sinistres_vehicule;
ALTER TABLE lometa_sinistres
DROP COLUMN IF EXISTS vehicule_sinistre_id;

-- Supprimer est_flotte
DROP INDEX IF EXISTS ix_lometa_sinistres_est_flotte;
ALTER TABLE lometa_sinistres
DROP COLUMN IF EXISTS est_flotte;

COMMIT;