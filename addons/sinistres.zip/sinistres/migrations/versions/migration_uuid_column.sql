SELECT table_name, column_name, data_type 
FROM information_schema.columns 
WHERE table_name LIKE 'lometa_%' 
AND column_name IN ('created_by', 'updated_by');

-- Script pour modifier toutes les tables LOMETA
DO $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN 
        SELECT table_name, column_name 
        FROM information_schema.columns 
        WHERE table_name LIKE 'lometa_%' 
        AND column_name IN ('created_by', 'updated_by')
        AND data_type = 'uuid'
    LOOP
        -- Rendre la colonne nullable temporairement
        EXECUTE format('ALTER TABLE %I ALTER COLUMN %I DROP NOT NULL', 
                      rec.table_name, rec.column_name);
        
        -- Changer le type
        EXECUTE format('ALTER TABLE %I ALTER COLUMN %I TYPE INTEGER USING NULL', 
                      rec.table_name, rec.column_name);
        
        RAISE NOTICE '✅ Modifié: %.%', rec.table_name, rec.column_name;
    END LOOP;
END $$;