-- ============================================================
-- MIGRATION 002 : Ajout flotte/véhicule au sinistre
-- Ordre : 1) colonnes  2) FK  3) index  4) contrainte  5) update
-- ============================================================

BEGIN;

-- ============================================================
-- ÉTAPE 1 : Ajouter les colonnes
-- ============================================================

ALTER TABLE lometa_sinistres
ADD COLUMN IF NOT EXISTS est_flotte BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE lometa_sinistres
ADD COLUMN IF NOT EXISTS vehicule_sinistre_id INTEGER;

ALTER TABLE lometa_sinistres
ADD COLUMN IF NOT EXISTS flotte_id INTEGER;

-- ============================================================
-- ÉTAPE 2 : Ajouter les FK
-- ============================================================

-- FK vers vehicles
ALTER TABLE lometa_sinistres
DROP CONSTRAINT IF EXISTS fk_lometa_sinistres_vehicule;

ALTER TABLE lometa_sinistres
ADD CONSTRAINT fk_lometa_sinistres_vehicule
FOREIGN KEY (vehicule_sinistre_id)
REFERENCES vehicles(id)
ON DELETE SET NULL;

-- FK vers fleets
ALTER TABLE lometa_sinistres
DROP CONSTRAINT IF EXISTS fk_lometa_sinistres_flotte;

ALTER TABLE lometa_sinistres
ADD CONSTRAINT fk_lometa_sinistres_flotte
FOREIGN KEY (flotte_id)
REFERENCES fleets(id)
ON DELETE SET NULL;

-- ============================================================
-- ÉTAPE 3 : Index
-- ============================================================

CREATE INDEX IF NOT EXISTS ix_lometa_sinistres_est_flotte
    ON lometa_sinistres (est_flotte);

CREATE INDEX IF NOT EXISTS ix_lometa_sinistres_vehicule_sinistre_id
    ON lometa_sinistres (vehicule_sinistre_id);

CREATE INDEX IF NOT EXISTS ix_lometa_sinistres_flotte_id
    ON lometa_sinistres (flotte_id);

-- ============================================================
-- ÉTAPE 4 : Contrainte de cohérence
-- ============================================================

ALTER TABLE lometa_sinistres
DROP CONSTRAINT IF EXISTS ck_lometa_sinistres_flotte_vehicule;

ALTER TABLE lometa_sinistres
ADD CONSTRAINT ck_lometa_sinistres_flotte_vehicule
CHECK (
    (est_flotte = false)
    OR
    (est_flotte = true AND vehicule_sinistre_id IS NOT NULL)
);

-- ============================================================
-- ÉTAPE 5 : Initialiser est_flotte pour les sinistres existants
-- ============================================================

UPDATE lometa_sinistres
SET est_flotte = false
WHERE est_flotte IS NULL;

COMMIT;