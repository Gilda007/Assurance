-- ============================================================
-- Migration 002 : Ajout gestion flotte/véhicule au sinistre
-- Date : 2026-09-14
-- ============================================================

BEGIN;

-- ============================================================
-- 1. Ajout de la colonne est_flotte
-- ============================================================
ALTER TABLE lometa_sinistres
ADD COLUMN IF NOT EXISTS est_flotte BOOLEAN NOT NULL DEFAULT false;

COMMENT ON COLUMN lometa_sinistres.est_flotte IS 
    'Indique si le sinistre concerne un contrat flotte (préfixe FLT)';

CREATE INDEX IF NOT EXISTS ix_lometa_sinistres_est_flotte
    ON lometa_sinistres (est_flotte);

-- ============================================================
-- 2. Ajout de la colonne vehicule_sinistre_id
-- ============================================================
ALTER TABLE lometa_sinistres
ADD COLUMN IF NOT EXISTS vehicule_sinistre_id INTEGER;

COMMENT ON COLUMN lometa_sinistres.vehicule_sinistre_id IS 
    'Véhicule sinistré (obligatoire si est_flotte=True)';

-- FK vers automobiles (à adapter si le nom diffère)
ALTER TABLE lometa_sinistres
ADD CONSTRAINT fk_lometa_sinistres_vehicule
FOREIGN KEY (vehicule_sinistre_id)
REFERENCES automobiles(id)
ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS ix_lometa_sinistres_vehicule_sinistre_id
    ON lometa_sinistres (vehicule_sinistre_id);

-- ============================================================
-- 3. Ajout de la colonne flotte_id
-- ============================================================
ALTER TABLE lometa_sinistres
ADD COLUMN IF NOT EXISTS flotte_id INTEGER;

COMMENT ON COLUMN lometa_sinistres.flotte_id IS 
    'Flotte associée au sinistre (si est_flotte=True)';

ALTER TABLE lometa_sinistres
ADD CONSTRAINT fk_lometa_sinistres_flotte
FOREIGN KEY (flotte_id)
REFERENCES fleets(id)
ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS ix_lometa_sinistres_flotte_id
    ON lometa_sinistres (flotte_id);

-- ============================================================
-- 4. Contrainte de cohérence
-- ============================================================
-- Un sinistre flotte DOIT avoir un véhicule identifié
ALTER TABLE lometa_sinistres
ADD CONSTRAINT ck_lometa_sinistres_flotte_vehicule
CHECK (
    (est_flotte = false) 
    OR 
    (est_flotte = true AND vehicule_sinistre_id IS NOT NULL)
);

-- ============================================================
-- 5. Mise à jour des données existantes
-- ============================================================
UPDATE lometa_sinistres
SET est_flotte = false
WHERE est_flotte IS NULL;

COMMIT;

-- ============================================================
-- Vérification
-- ============================================================
-- SELECT column_name, data_type, is_nullable, column_default
-- FROM information_schema.columns
-- WHERE table_name = 'lometa_sinistres'
--   AND column_name IN ('est_flotte', 'vehicule_sinistre_id', 'flotte_id');