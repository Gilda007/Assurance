"""Tests du module."""
