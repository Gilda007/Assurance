"""Package du module Sinistres."""
